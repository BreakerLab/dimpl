#!/bin/bash

module load dSQ

thiscmd=`realpath $0`
parent_dir="$(dirname $thiscmd)"
batchfile=$parent_dir/scripts/blast_batchfile.sh
jobfile=$parent_dir/scripts/blast_jobfile.sh

echo "Generating batchfile at $batchfile"
dSQ.py --jobfile $jobfile --batch-file $batchfile --nice \
  --partition pi_breaker --mem 70G --chdir $parent_dir \
  --output blast_output%4a.out --job-name blast.$(basename $parent_dir)

sbatch $batchfile
