#!/bin/bash
#SBATCH --array 0-107
#SBATCH --output blast_output%4a.out
#SBATCH --job-name blast.Francisella_tularensis_GCA_000008985.1_0.5_2.0_blastdata
#SBATCH --nice --partition pi_breaker --mem 70G --chdir /gpfs/ysm/project/breaker/kib4/igr-search/Francisella_tularensis_GCA_000008985.1_0.5_2.0_blastdata

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/0.96/dSQBatch.py /gpfs/ysm/project/breaker/kib4/igr-search/Francisella_tularensis_GCA_000008985.1_0.5_2.0_blastdata/scripts/blast_jobfile.sh /gpfs/ysm/project/breaker/kib4/igr-search

