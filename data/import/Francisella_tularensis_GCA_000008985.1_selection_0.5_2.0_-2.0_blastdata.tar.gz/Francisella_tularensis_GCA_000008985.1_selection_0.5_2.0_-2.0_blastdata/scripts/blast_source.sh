#!/bin/bash
BLASTCMD="blastx -evalue 0.01 -outfmt 5 -db nr -query"
export BLASTDB=/ysm-gpfs/datasets/db/blast
module load BLAST+
