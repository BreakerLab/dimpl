#!/bin/bash
#SBATCH --array 0-107
#SBATCH --output output/blast_output%4a.out
#SBATCH --job-name blast.Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_blastdata
#SBATCH --nice --partition pi_breaker --mem 70G --chdir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_blastdata

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/1.05/dSQBatch.py --job-file /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_blastdata/scripts/blast_jobfile.sh --status-dir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_blastdata

