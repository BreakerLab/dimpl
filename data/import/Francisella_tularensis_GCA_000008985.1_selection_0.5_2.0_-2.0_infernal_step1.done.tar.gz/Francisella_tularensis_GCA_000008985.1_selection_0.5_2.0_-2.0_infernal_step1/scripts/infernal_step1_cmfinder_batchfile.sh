#!/bin/bash
#SBATCH --array 0-50
#SBATCH --output output/cmfinder_output%4a.out
#SBATCH --job-name cmfinder.Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1
#SBATCH --partition pi_breaker --mem 16G --chdir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1 --dependency afterany:46440181 --cpus-per-task 2 --time 48:0:0

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/1.05/dSQBatch.py --job-file /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1/scripts/infernal_step1_cmfinder_jobfile.sh --status-dir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

