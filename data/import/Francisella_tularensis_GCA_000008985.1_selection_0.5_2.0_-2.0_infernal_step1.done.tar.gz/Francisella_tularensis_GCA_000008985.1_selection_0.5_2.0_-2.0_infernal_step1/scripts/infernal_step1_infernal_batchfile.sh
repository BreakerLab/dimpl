#!/bin/bash
#SBATCH --array 0-50
#SBATCH --output output/infernal_output%4a.out
#SBATCH --job-name infernal.Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1
#SBATCH -t 1-0 --partition pi_breaker --mem 8G --chdir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/1.05/dSQBatch.py --job-file /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1/scripts/infernal_step1_infernal_jobfile.sh --status-dir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

