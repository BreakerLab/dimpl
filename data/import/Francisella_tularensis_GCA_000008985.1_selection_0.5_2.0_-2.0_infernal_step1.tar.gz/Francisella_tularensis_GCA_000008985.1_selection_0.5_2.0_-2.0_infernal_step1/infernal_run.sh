#!/bin/bash
STEPDIR=infernal_step1

module load dSQ

PARTITION=pi_breaker

thiscmd=`realpath $0`
parent_dir="$(dirname $thiscmd)"
mkdir -p $parent_dir/output
infernal_batchfile=$parent_dir/scripts/infernal_batchfile.sh
infernal_jobfile=$parent_dir/scripts/infernal_jobfile.sh

echo "Generating infernal batchfile at $infernal_batchfile"
dSQ.py --jobfile $infernal_jobfile --batch-file $infernal_batchfile --nice \
  --partition $PARTITION --mem 8G --chdir $parent_dir --status-dir $parent_dir \
  --output output/infernal_output%4a.out --job-name infernal.$(basename $parent_dir)
infernal_RESPONSE=$(sbatch $infernal_batchfile)
infernal_JOBID=${infernal_RESPONSE##* }

# Fallback option to retry any jobs that fail due to error code 137 out of memory errors
infernal_bigmem_batchfile=$parent_dir/scripts/infernal_bigmem_batchfile.sh
infernal_bigmem_jobfile=$parent_dir/scripts/infernal_bigmem_jobfile.sh
infernal_bigmem_dsq="dSQ.py --jobfile $infernal_bigmem_jobfile --batch-file $infernal_bigmem_batchfile --nice \
  --partition $PARTITION --mem 32G --chdir $parent_dir --status-dir $parent_dir -c 4 --time 2-0\
  --output output/infernal_bigmem_output%4a.out --job-name infernal_bigmem.$(basename $parent_dir) --submit"
bigmem_COMMAND=$'#!/bin/bash \n'"module load dSQ; cat $parent_dir/job_${infernal_JOBID}_status.tsv | cut -f 2,7 | grep ^137 | cut -f2 > $infernal_bigmem_jobfile; $infernal_bigmem_dsq"
bigmem_RESPONSE=$(echo "$bigmem_COMMAND" | sbatch -p $PARTITION --dependency afterany:${infernal_JOBID} --job-name dsq_bigmem_infernal.$(basename $parent_dir))
bigmem_JOBID=${bigmem_RESPONSE##* }

# Convert all the results' .sto files into fasta files
fasta_COMMAND=$'#!/bin/bash\n module load HMMER; find . -type f -name \*.cm.align.sto -ls | awk \'($2>0){print $11}\' | xargs -I{} basename {} .cm.align.sto | xargs -I{} sh -c "esl-reformat fasta {}/{}.cm.align.sto > {}/{}.cmsearch.fasta"'
fasta_RESPONSE=$(echo "$fasta_COMMAND" | sbatch -p $PARTITION --dependency afterany:${bigmem_JOBID} --job-name sto2fasta.$(basename $parent_dir) --chdir $parent_dir/$STEPDIR --output ../output/sto2fasta.out)
fasta_JOBID=${fasta_RESPONSE##* }

# For fasta files with more than 1000 hits, take a random sample of 1000.
sample_COMMAND="#!/bin/bash\nfind . -type f -name \*.cmsearch.fasta -ls |\n xargs -I{} basename {} .fasta |\n  xargs -I@@ bash -c \"awk 'BEGIN {RS=\\\">\\\";FS=\\\"\\\n\\\"} NR>1 {seq=\\\"\\\"; for (i=2;i<=NF;i++) seq=seq\\\$i; print \\\">\\\"\\\$1\\\"\\\t\\\"seq}' @@.fasta |\n   sort -u -k2,2 |\n   tee >(shuf -n 1000 | awk 'BEGIN {FS=\\\"\\\t\\\"} {print \\\$1; print \\\$2}' > @@.sample.fasta) |\n   awk 'BEGIN {FS=\\\"\\\t\\\"} {print \\\$1; print \\\$2}' > @@.dedupe.fasta\""
sample_RESPONSE=$(echo -e "$sample_COMMAND" | sbatch -p $PARTITION --dependency afterany:${fasta_JOBID} --job-name samplefasta.$(basename $parent_dir) --chdir $parent_dir/$STEPDIR --output ../output/samplefasta.out)
sample_JOBID=${sample_RESPONSE##* }


cmfinder_batchfile=$parent_dir/scripts/cmfinder_batchfile.sh
cmfinder_jobfile=$parent_dir/scripts/cmfinder_jobfile.sh

echo "Generating cmfinder batchfile at $cmfinder_batchfile"
dSQ.py --jobfile $cmfinder_jobfile --batch-file $cmfinder_batchfile --nice \
  --partition pi_breaker --mem 16G --chdir $parent_dir --status-dir $parent_dir \
  --output output/cmfinder_output%4a.out --job-name cmfinder.$(basename $parent_dir) \
  --dependency afterany:${sample_JOBID} --cpus-per-task 2 --time 48:0:0

cmfinder_RESPONSE=$(sbatch $cmfinder_batchfile)
cmfinder_JOBID=${cmfinder_RESPONSE##* }
