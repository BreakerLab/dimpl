#!/bin/bash
#SBATCH --output output/cmfinder_output%4a.out
#SBATCH --array 0-50
#SBATCH --job-name cmfinder.Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1
#SBATCH --nice --partition pi_breaker --mem 16G --chdir /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1 --dependency afterany:51118977 --cpus-per-task 2 --time 48:0:0

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/0.96/dSQBatch.py /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1/scripts/cmfinder_jobfile.sh /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

