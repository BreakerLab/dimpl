STEPDIR=infernal_step1
export PATH=$PATH:/home/kib4/exe/cmfinder-0.4.1.18/bin/
SEQDIR=$STEPDIR/$SEQNAME
CMFINDERCOMMAND="cmfinder04.pl -minCandScoreInFinal 10 -combine -fragmentary --allCpus -commaSepEmFlags x--filter-non-frag,--max-degen-per-hit,2,--max-degen-flanking-nucs,7,--degen-keep,--amaa $SEQDIR/$SEQNAME.sample.fasta "