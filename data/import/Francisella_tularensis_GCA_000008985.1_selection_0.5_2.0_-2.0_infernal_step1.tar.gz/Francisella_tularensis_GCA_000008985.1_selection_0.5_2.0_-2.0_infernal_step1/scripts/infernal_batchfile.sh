#!/bin/bash
#SBATCH --output output/infernal_output%4a.out
#SBATCH --array 0-50
#SBATCH --job-name infernal.Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1
#SBATCH --nice --partition pi_breaker --mem 8G --chdir /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/0.96/dSQBatch.py /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1/scripts/infernal_jobfile.sh /gpfs/ysm/project/breaker/kib4/igr-search/infernal_step1/Francisella_tularensis_GCA_000008985.1_selection_0.5_2.0_-2.0_infernal_step1

