#/bin/bash

name=`pwd |sed 's#.*/##'`
cd ..
tar czf ${name}.done.tar.gz ${name}
if [ $? -eq 0 ]; then
    echo "tar file created in parent directory."
fi
