#!/bin/bash
#SBATCH --array 0
#SBATCH --output output/cmfinder_output%4a.out
#SBATCH --job-name cmfinder.riboswitch_candidates_infernal_step2
#SBATCH --partition pi_breaker --mem 16G --chdir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2 --dependency afterany:46654594 --cpus-per-task 2 --time 48:0:0

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/1.05/dSQBatch.py --job-file /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2/scripts/infernal_step2_cmfinder_jobfile.sh --status-dir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2

