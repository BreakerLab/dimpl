#!/bin/bash
#SBATCH --array 0
#SBATCH --output output/infernal_output%4a.out
#SBATCH --job-name infernal.riboswitch_candidates_infernal_step2
#SBATCH -t 1-0 --partition pi_breaker --mem 8G --chdir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/1.05/dSQBatch.py --job-file /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2/scripts/infernal_step2_infernal_jobfile.sh --status-dir /gpfs/ysm/project/breaker/gg485/for/ken/DIMPL/test_config_mod/riboswitch_candidates_infernal_step2

