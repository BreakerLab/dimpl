SEQNAME=purF-consensus; source scripts/infernal_step2_infernal_source.sh; $CMBUILDCOMMAND && $CMCALIBRATECOMMAND && $CMSEARCHCOMMAND
