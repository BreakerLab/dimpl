SEQNAME=20191011-purF-extended-nodupe; source scripts/infernal_step2_cmfinder_source.sh; $CMFINDERCOMMAND
