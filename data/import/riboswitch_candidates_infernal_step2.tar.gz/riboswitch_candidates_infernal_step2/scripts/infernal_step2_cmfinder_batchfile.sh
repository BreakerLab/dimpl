#!/bin/bash
#SBATCH --output output/cmfinder_output%4a.out
#SBATCH --array 0
#SBATCH --job-name cmfinder.riboswitch_candidates_infernal_step2
#SBATCH --partition pi_breaker --mem 16G --chdir /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2 --dependency afterany:9479694 --cpus-per-task 2 --time 48:0:0

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/0.96/dSQBatch.py /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2/scripts/infernal_step2_cmfinder_jobfile.sh /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2

