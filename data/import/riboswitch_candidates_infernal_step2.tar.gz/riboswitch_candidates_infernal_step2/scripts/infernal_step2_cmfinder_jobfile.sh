SEQNAME=purF-consensus; source scripts/infernal_step2_cmfinder_source.sh; $CMFINDERCOMMAND
