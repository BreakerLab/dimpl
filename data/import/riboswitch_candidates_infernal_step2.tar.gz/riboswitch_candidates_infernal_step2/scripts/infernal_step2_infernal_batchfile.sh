#!/bin/bash
#SBATCH --output output/infernal_output%4a.out
#SBATCH --array 0
#SBATCH --job-name infernal.riboswitch_candidates_infernal_step2
#SBATCH -t 1-0 --partition pi_breaker --mem 8G --chdir /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2

# DO NOT EDIT LINE BELOW
/ysm-gpfs/apps/software/dSQ/0.96/dSQBatch.py /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2/scripts/infernal_step2_infernal_jobfile.sh /gpfs/ysm/project/breaker/kib4/dimpl/riboswitch_candidates_infernal_step2

