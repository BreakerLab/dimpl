SEQNAME=20191011-purF-extended-nodupe; source scripts/infernal_step2_infernal_source.sh; $CMBUILDCOMMAND && $CMCALIBRATECOMMAND && $CMSEARCHCOMMAND
